class InfileMetadata:
    def __init__(self, csv_name, cols, infileType):
        self.csv_name = csv_name
        self.cols = (cols,)
        self.infileType = infileType
