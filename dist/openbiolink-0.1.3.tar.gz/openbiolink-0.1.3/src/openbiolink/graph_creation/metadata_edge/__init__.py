from openbiolink.graph_creation.metadata_edge.edge import *
from openbiolink.graph_creation.metadata_edge.edgeMetadata import EdgeMetadata
from openbiolink.graph_creation.metadata_edge.onto import *
