from openbiolink.graph_creation.file_reader.onto.ontoDoReader import OntoDoReader
from openbiolink.graph_creation.file_reader.onto.ontoGoReader import OntoGoReader
from openbiolink.graph_creation.file_reader.onto.ontoHpoReader import OntoHpoReader
from openbiolink.graph_creation.file_reader.onto.ontoUberonReader import OntoUberonReader
