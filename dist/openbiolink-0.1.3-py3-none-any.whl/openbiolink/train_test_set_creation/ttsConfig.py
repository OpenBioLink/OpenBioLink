TTS_FOLDER_NAME = "train_test_data"
CROSS_VAL_FOLDER_NAME = "cross_val"
FOLD_FOLDER_PREFIX = "fold_"
NEGATIVE_PREFIX = "negative_"

TEST_FILE_NAME = "test_sample.csv"
TRAIN_FILE_NAME = "train_sample.csv"
VAL_FILE_NAME = "val_sample.csv"

NEW_TEST_NODES_FILE_NAME = "removed_test_nodes.csv"
NEW_VAL_NODES_FILE_NAME = "removed_val_nodes.csv"

TRAIN_VAL_NODES_FILE_NAME = "train_val_nodes.csv"
TRAIN_NODES_FILE_NAME = "train_nodes.csv"
VAL_NODES_FILE_NAME = "val_nodes.csv"
TEST_NODES_FILE_NAME = "test_nodes.csv"

VANISHED_FILE_NAME = "vanished_edges.csv"

EDGE_TYPE_KEY_NAME = "edge_type_key"
