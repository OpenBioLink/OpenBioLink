from openbiolink.graph_creation.file_processor.edge import *
from openbiolink.graph_creation.file_processor.fileProcessor import FileProcessor
from openbiolink.graph_creation.file_processor.mapping import *
from openbiolink.graph_creation.file_processor.onto import *
from openbiolink.graph_creation.file_processor.onto_mapping import *
